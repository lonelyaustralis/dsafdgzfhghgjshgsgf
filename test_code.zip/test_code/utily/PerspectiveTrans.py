from .cfg import load_cfg
import cv2
import numpy as np

# import time


class PerspectiveTrans:
    def __init__(self, config_path):
        self.args = load_cfg(config_path)

    def __call__(self, img):
        warped, have_wafer_flag = self.warp_v2(img)
        if have_wafer_flag == 0:
            return 0, 0
        warped = cv2.rotate(warped, cv2.ROTATE_180)
        warped = cv2.resize(warped, (800, 800))
        # cv2.imshow("warped", warped)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        return warped, 1

    def warp_v2(self, img):
        def roi_get(img):
            hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # 转换位HSV格式
            lower_param = np.array([14, 10, 0])
            upper_param = np.array([87, 255, 255])
            mask = cv2.inRange(hsv_img, lower_param, upper_param)
            # mask_copy = mask.copy()
            # mask_copy = cv2.cvtColor(mask_copy, cv2.COLOR_GRAY2BGR)

            # start_time = time.time()
            mask_rate = (mask // 255).sum() / (mask.shape[0] * mask.shape[1])
            if mask_rate < 0.01:
                return 0, 0, 0
            # print("mask_rate_time:", time.time() - start_time)
            cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
            # cv2.drawContours(mask_copy, cnts, -1, (0, 0, 255), 24)
            # cv2.imshow("mask_copy", mask_copy)
            # cv2.imwrite("ff.jpg", mask_copy)
            max_cnts = [0]
            for cnt in cnts:
                if len(cnt) > len(max_cnts):
                    max_cnts = cnt
            hole = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
            cv2.drawContours(hole, [max_cnts], -1, 255, -1)
            max_h = int(max(max_cnts[:, :, 1]))
            min_h = int(min(max_cnts[:, :, 1]))
            max_v = int(max(max_cnts[:, :, 0]))
            min_v = int(min(max_cnts[:, :, 0]))
            # mask_img = cv2.bitwise_and(img, img, mask=mask)
            # cv2.imshow("mask_img", mask_img)
            return img[min_h:max_h, min_v:max_v], hole[min_h:max_h, min_v:max_v], 1

        line_dict = {}
        img_copy = img.copy()
        # start_time = time.time()
        roi, hole, have_wafer_flag = roi_get(img_copy)
        # cv2.imwrite("roi.jpg", roi)
        # cv2.imwrite("hole.jpg", hole)

        if have_wafer_flag == 0:
            return 0, 0
        h, w = roi.shape[0], roi.shape[1]
        # 左边
        leftRow = int(h * (1 / 10))
        leftCol = 0
        rightRow = int(h * (3 / 5))
        rightCol = int(w * (3 / 40))
        left_img = roi[leftRow:rightRow, leftCol:rightCol]
        left_mask = hole[leftRow:rightRow, leftCol:rightCol]
        # left_img = cv2.resize(left_img, (800, 800))
        roi_canny = cv2.Canny(left_img, 60, 100, 7)
        roi_canny = cv2.bitwise_and(roi_canny, roi_canny, mask=left_mask)
        lines = cv2.HoughLinesP(roi_canny, 1, np.pi / 180, 70, minLineLength=120, maxLineGap=100)  # [:300]
        if lines is None:
            return 0, 0
        # # lines = FLD(roi)
        angles = []
        avg_angles = 0
        # count = 0
        clear_line = []
        for l in lines:
            l = l[0]
            # cv2.line(left_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            angle = round(np.arctan(self.line_angle(l)) * 180 / np.pi)
            if abs(angle) > 50:
                # avg_angles = angle + avg_angles
                # count += 1
                angles.append(angle)
                clear_line.append(l)
        angles_set = list(set(angles))
        angles_set.sort()
        angles_count = [angles.count(i) for i in angles_set]
        max_index = int(np.argmax(angles_count))
        if len(angles_count) >= 3:
            if max_index == 0:
                second_index = max_index + 1
                thrid_index = max_index + 2
            elif max_index == len(angles_count) - 1:
                second_index = max_index - 1
                thrid_index = max_index - 2
            else:
                second_index = max_index + 1
                thrid_index = max_index - 1
            sum_count = angles_count[max_index]
            avg_angles = angles_set[max_index] * angles_count[max_index]
            if abs(angles_set[max_index] - angles_set[second_index]) < 3:
                avg_angles += angles_set[second_index] * angles_count[second_index]
                sum_count += angles_count[second_index]
            if abs(angles_set[max_index] - angles_set[thrid_index]) < 3:
                avg_angles += angles_set[thrid_index] * angles_count[thrid_index]
                sum_count += angles_count[thrid_index]
            avg_angles /= sum_count
            # avg_angles = (
            #     angles_count[max_index] * angles_set[max_index]
            #     + angles_count[second_index] * angles_set[second_index]
            #     + angles_count[thrid_index] * angles_set[thrid_index]
            # )
            # avg_angles = avg_angles / (angles_count[max_index] + angles_count[second_index] + angles_count[thrid_index])
        else:
            avg_angles = angles_set[max_index]
        # avg_angles = avg_angles / count
        clear_line2 = []

        for i in range(len(angles)):
            if abs(angles[i] - avg_angles) < 2:
                # l = clear_line[i]
                clear_line2.append(clear_line[i])
                # cv2.line(left_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
        min_xy = np.array([min((i[0] + i[1]), (i[2] + i[3])) for i in clear_line2])
        min_index = int(np.argmin(min_xy))
        l = clear_line2[min_index]
        # cv2.line(left_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
        l[0] += leftCol
        l[2] += leftCol
        l[1] += leftRow
        l[3] += leftRow
        line_dict["L"] = l

        # roi = cv2.resize(roi, (800, 800))
        # cv2.imshow("left_img", left_img)

        # 右边
        leftRow = int(h * (2 / 10))
        leftCol = int(w * (19 / 20))
        rightRow = int(h * (4 / 5))
        rightCol = int(w)
        right_img = roi[leftRow:rightRow, leftCol:rightCol]
        right_mask = hole[leftRow:rightRow, leftCol:rightCol]
        # left_img = cv2.resize(left_img, (800, 800))
        roi_canny = cv2.Canny(right_img, 60, 100, 7)
        roi_canny = cv2.bitwise_and(roi_canny, roi_canny, mask=right_mask)
        lines = cv2.HoughLinesP(roi_canny, 1, np.pi / 180, 70, minLineLength=100, maxLineGap=100)  # [:300]
        if lines is None:
            return 0, 0
        angles = []
        clear_line = []
        for l in lines:
            l = l[0]
            angle = round(np.arctan(self.line_angle(l)) * 180 / np.pi)
            # print(angle)
            # cv2.line(right_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            # cv2.imshow("roi", right_img)
            # cv2.waitKey(0)
            if abs(angle) > 70:
                angles.append(angle)
                clear_line.append(l)

        angles_set = list(set(angles))
        angles_set.sort()
        angles_count = [angles.count(i) for i in angles_set]
        max_index = int(np.argmax(angles_count))
        if len(angles_count) >= 3:
            if max_index == 0:
                second_index = max_index + 1
                thrid_index = max_index + 2
            elif max_index == len(angles_count) - 1:
                second_index = max_index - 1
                thrid_index = max_index - 2
            else:
                second_index = max_index + 1
                thrid_index = max_index - 1
            sum_count = angles_count[max_index]
            avg_angles = angles_set[max_index] * angles_count[max_index]
            if abs(angles_set[max_index] - angles_set[second_index]) < 3:
                avg_angles += angles_set[second_index] * angles_count[second_index]
                sum_count += angles_count[second_index]
            if abs(angles_set[max_index] - angles_set[thrid_index]) < 3:
                avg_angles += angles_set[thrid_index] * angles_count[thrid_index]
                sum_count += angles_count[thrid_index]
            avg_angles /= sum_count
        else:
            avg_angles = angles_set[max_index]
        # avg_angles = avg_angles / count
        clear_line2 = []

        for i in range(len(angles)):
            if abs(abs(angles[i]) - abs(avg_angles)) < 2:
                l = clear_line[i]
                # cv2.line(right_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
                clear_line2.append(clear_line[i])
        min_xy = np.array([min(i[0], i[2]) for i in clear_line2])
        min_index = int(np.argmin(min_xy))
        l = clear_line2[min_index]
        cv2.line(right_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
        l[0] += leftCol
        l[2] += leftCol
        l[1] += leftRow
        l[3] += leftRow
        line_dict["R"] = l
        # cv2.line(right_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
        # cv2.imshow("right_img", right_img)
        # print(angles)

        # 顶边
        leftRow = 0
        leftCol = int(w * (1 / 5))
        rightRow = int(h * (2 / 40))
        rightCol = int(w)
        top_img = roi[leftRow:rightRow, leftCol:rightCol]
        top_mask = hole[leftRow:rightRow, leftCol:rightCol]
        roi_canny = cv2.Canny(top_img, 20, 70, 7)
        roi_canny = cv2.bitwise_and(roi_canny, roi_canny, mask=top_mask)
        top_img = cv2.bitwise_and(top_img, top_img, mask=top_mask)
        lines = cv2.HoughLinesP(roi_canny, 1, np.pi / 180, 70, minLineLength=150, maxLineGap=80)  # [:300]
        if lines is None:
            return 0, 0
        angles = []
        clear_line = []
        div_clear_line = []
        for l in lines:
            l = l[0]
            # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            if int(0.5 * (l[1] + l[3])) - 30 <= 0 or int(0.5 * (l[1] + l[3])) + 20 >= top_img.shape[0]:
                continue
            if int(0.4 * l[1] + 0.6 * l[3]) - 10 <= 0 or int(0.4 * l[1] + 0.6 * l[3]) + 10 >= top_img.shape[0]:
                continue
            if int(0.6 * l[1] + 0.4 * l[3]) - 10 <= 0 or int(0.6 * l[1] + 0.4 * l[3]) + 10 >= top_img.shape[0]:
                continue
            if top_img[int(0.5 * (l[1] + l[3])) - 30, int(0.5 * (l[0] + l[2]))].sum() <= 10:
                continue
            if top_img[int(0.5 * (l[1] + l[3])) + 20, int(0.5 * (l[0] + l[2]))].sum() <= 10:
                continue
            if top_img[int(0.4 * l[1] + 0.6 * l[3]) - 10, int(0.4 * l[0] + 0.6 * l[2])].sum() <= 10:
                continue
            if top_img[int(0.4 * l[1] + 0.6 * l[3]) + 10, int(0.4 * l[0] + 0.6 * l[2])].sum() <= 10:
                continue
            if top_img[int(0.6 * l[1] + 0.4 * l[3]) - 10, int(0.6 * l[0] + 0.4 * l[2])].sum() <= 10:
                continue
            if top_img[int(0.6 * l[1] + 0.4 * l[3]) + 10, int(0.6 * l[0] + 0.4 * l[2])].sum() <= 10:
                continue
            div_clear_line.append(l)
        estimate_line_flag = False
        if len(div_clear_line) == 0:
            estimate_line_flag = True
            for l in lines:
                l = l[0]
                # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
                if int(0.5 * (l[1] + l[3])) - 20 <= 0 or int(0.5 * (l[1] + l[3])) + 20 >= top_img.shape[0]:
                    continue
                if int(0.4 * l[1] + 0.6 * l[3]) - 10 <= 0 or int(0.4 * l[1] + 0.6 * l[3]) + 10 >= top_img.shape[0]:
                    continue
                if int(0.6 * l[1] + 0.4 * l[3]) - 10 <= 0 or int(0.6 * l[1] + 0.4 * l[3]) + 10 >= top_img.shape[0]:
                    continue
                div_clear_line.append(l)
        if len(div_clear_line) == 0:
            return 0, 0

        for l in div_clear_line:
            # l = l[0]
            angle = round(np.arctan(self.line_angle(l)) * 180 / np.pi, 0)
            # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            if abs(angle) < 20:
                angles.append(angle)
                clear_line.append(l)
        if len(clear_line) == 0:
            return 0, 0
        # print(angles)
        angles_set = list(set(angles))
        angles_set.sort()
        angles_count = [angles.count(i) for i in angles_set]
        max_index = int(np.argmax(angles_count))
        if len(angles_count) >= 3:
            if max_index == 0:
                second_index = max_index + 1
                thrid_index = max_index + 2
            elif max_index == len(angles_count) - 1:
                second_index = max_index - 1
                thrid_index = max_index - 2
            else:
                second_index = max_index + 1
                thrid_index = max_index - 1
            sum_count = angles_count[max_index]
            avg_angles = angles_set[max_index] * angles_count[max_index]
            if abs(angles_set[max_index] - angles_set[second_index]) < 1:
                avg_angles += angles_set[second_index] * angles_count[second_index]
                sum_count += angles_count[second_index]
            if abs(angles_set[max_index] - angles_set[thrid_index]) < 1:
                avg_angles += angles_set[thrid_index] * angles_count[thrid_index]
                sum_count += angles_count[thrid_index]
            avg_angles /= sum_count
            avg_angles_flag = 1
        else:
            avg_angles_flag = 0
            # avg_angles = angles_set[max_index]
        # clear_line2 = []
        max_r = 0
        max_line = clear_line[0]
        for i in range(len(angles)):
            if avg_angles_flag:
                if abs(angles[i] - avg_angles) > 1:
                    continue
            # clear_line2.append(clear_line[i])
            l = clear_line[i]
            # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            top_img = top_img.astype(np.float32)
            r1 = top_img[int(0.5 * (l[1] + l[3])) - 10, int(0.5 * (l[0] + l[2]))] - top_img[int(0.5 * (l[1] + l[3])) + 10, int(0.5 * (l[0] + l[2]))]

            r2 = (
                top_img[int(0.4 * l[1] + 0.6 * l[3]) - 10, int(0.4 * l[0] + 0.6 * l[2])]
                - top_img[int(0.4 * l[1] + 0.6 * l[3]) + 10, int(0.4 * l[0] + 0.6 * l[2])]
            )

            r3 = (
                top_img[int(0.6 * l[1] + 0.4 * l[3]) - 10, int(0.6 * l[0] + 0.4 * l[2])]
                - top_img[int(0.6 * l[1] + 0.4 * l[3]) + 10, int(0.6 * l[0] + 0.4 * l[2])]
            )
            r0 = [abs(r1[0]), abs(r2[0]), abs(r3[0])]
            r0.sort()
            max_r0 = r0[1]
            max_r1 = max(abs(r1[1]), abs(r2[1]), abs(r3[1]))
            max_r2 = max(abs(r1[2]), abs(r2[2]), abs(r3[2]))
            if max_r1 > 50 or max_r2 > 50:
                continue
            if max_r0 > max_r:
                max_r = max_r0
                max_line = l

        l = max_line
        if estimate_line_flag:
            estimate_pixel = 35
            if l[1] == l[3]:
                l[1] += l[1] + estimate_pixel
                l[3] += l[3] + estimate_pixel
            else:
                xiebian = np.sqrt((l[2] - l[0]) ** 2 + (l[3] - l[1]) ** 2)
                sina = abs(l[3] - l[1]) / xiebian
                cosa = abs(l[2] - l[0]) / xiebian
                row_change = estimate_pixel * cosa
                col_change = estimate_pixel * sina
                l[1] += row_change
                l[3] += row_change
                l[0] += col_change
                l[2] += col_change
        # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
        # top_img = top_img.astype(np.uint8)
        # cv2.imshow("top_img", top_img)
        # cv2.waitKey(0)
        l[0] += leftCol
        l[2] += leftCol
        l[1] += leftRow
        l[3] += leftRow
        line_dict["T"] = l
        # print(max_r)

        # 底边
        leftRow = int(h * (37 / 40))
        leftCol = int(w * (1 / 5))
        rightRow = h
        rightCol = int(w)
        bottom_img = roi[leftRow:rightRow, leftCol:rightCol]
        bottom_mask = hole[leftRow:rightRow, leftCol:rightCol]
        # left_img = cv2.resize(left_img, (800, 800))
        roi_canny = cv2.Canny(bottom_img, 20, 70, 7)
        # cv2.imshow("roi_canny", roi_canny)
        roi_canny = cv2.bitwise_and(roi_canny, roi_canny, mask=bottom_mask)
        bottom_img = cv2.bitwise_and(bottom_img, bottom_img, mask=bottom_mask)
        # cv2.imshow("bottom_img", bottom_img)
        # cv2.waitKey(0)

        lines = cv2.HoughLinesP(roi_canny, 1, np.pi / 180, 70, minLineLength=80, maxLineGap=100)  # [:300]
        if lines is None:
            return 0, 0
        angles = []
        clear_line = []
        div_clear_line = []
        for l in lines:
            l = l[0]
            # cv2.line(bottom_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            # cv2.imshow("bottom_img", bottom_img)
            # cv2.waitKey(0)
            if int(0.5 * (l[1] + l[3])) - 20 <= 0 or int(0.5 * (l[1] + l[3])) + 20 >= bottom_img.shape[0]:
                continue
            if int(0.4 * l[1] + 0.6 * l[3]) - 10 <= 0 or int(0.4 * l[1] + 0.6 * l[3]) + 10 >= bottom_img.shape[0]:
                continue
            if int(0.6 * l[1] + 0.4 * l[3]) - 10 <= 0 or int(0.6 * l[1] + 0.4 * l[3]) + 10 >= bottom_img.shape[0]:
                continue
            if bottom_img[int(0.5 * (l[1] + l[3])) - 20, int(0.5 * (l[0] + l[2]))].sum() <= 50:
                continue
            if bottom_img[int(0.5 * (l[1] + l[3])) + 20, int(0.5 * (l[0] + l[2]))].sum() <= 50:
                continue
            if bottom_img[int(0.4 * l[1] + 0.6 * l[3]) - 10, int(0.4 * l[0] + 0.6 * l[2])].sum() <= 50:
                continue
            if bottom_img[int(0.4 * l[1] + 0.6 * l[3]) + 10, int(0.4 * l[0] + 0.6 * l[2])].sum() <= 50:
                continue
            if bottom_img[int(0.6 * l[1] + 0.4 * l[3]) - 10, int(0.6 * l[0] + 0.4 * l[2])].sum() <= 50:
                continue
            if bottom_img[int(0.6 * l[1] + 0.4 * l[3]) + 10, int(0.6 * l[0] + 0.4 * l[2])].sum() <= 50:
                continue
            div_clear_line.append(l)

        if len(div_clear_line) == 0:
            return 0, 0

        for l in div_clear_line:
            # l = l[0]
            angle = round(np.arctan(self.line_angle(l)) * 180 / np.pi, 0)
            # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            if abs(angle) < 20:
                angles.append(angle)
                clear_line.append(l)
        if len(clear_line) == 0:
            return 0, 0
        # print(angles)
        angles_set = list(set(angles))
        angles_set.sort()
        angles_count = [angles.count(i) for i in angles_set]
        max_index = int(np.argmax(angles_count))
        if len(angles_count) >= 3:
            if max_index == 0:
                second_index = max_index + 1
                thrid_index = max_index + 2
            elif max_index == len(angles_count) - 1:
                second_index = max_index - 1
                thrid_index = max_index - 2
            else:
                second_index = max_index + 1
                thrid_index = max_index - 1
            sum_count = angles_count[max_index]
            avg_angles = angles_set[max_index] * angles_count[max_index]
            if abs(angles_set[max_index] - angles_set[second_index]) < 1:
                avg_angles += angles_set[second_index] * angles_count[second_index]
                sum_count += angles_count[second_index]
            if abs(angles_set[max_index] - angles_set[thrid_index]) < 1:
                avg_angles += angles_set[thrid_index] * angles_count[thrid_index]
                sum_count += angles_count[thrid_index]
            avg_angles /= sum_count
            avg_angles_flag = 1
        else:
            avg_angles_flag = 0
        max_r = 0
        max_line = clear_line[0]
        for i in range(len(angles)):
            if avg_angles_flag:
                if abs(angles[i] - avg_angles) > 1:
                    continue
            l = clear_line[i]
            bottom_img = bottom_img.astype(np.float32)
            r1 = (
                bottom_img[int(0.5 * (l[1] + l[3])) - 10, int(0.5 * (l[0] + l[2]))]
                - bottom_img[int(0.5 * (l[1] + l[3])) + 10, int(0.5 * (l[0] + l[2]))]
            )

            r2 = (
                bottom_img[int(0.4 * l[1] + 0.6 * l[3]) - 10, int(0.4 * l[0] + 0.6 * l[2])]
                - bottom_img[int(0.4 * l[1] + 0.6 * l[3]) + 10, int(0.4 * l[0] + 0.6 * l[2])]
            )

            r3 = (
                bottom_img[int(0.6 * l[1] + 0.4 * l[3]) - 10, int(0.6 * l[0] + 0.4 * l[2])]
                - bottom_img[int(0.6 * l[1] + 0.4 * l[3]) + 10, int(0.6 * l[0] + 0.4 * l[2])]
            )
            r0 = [abs(r1[0]), abs(r2[0]), abs(r3[0])]
            r0.sort()
            max_r0 = r0[1]
            max_r1 = max(abs(r1[1]), abs(r2[1]), abs(r3[1]))
            max_r2 = max(abs(r1[2]), abs(r2[2]), abs(r3[2]))
            if max_r1 > 50 or max_r2 > 50:
                continue
            # cv2.line(top_img, (int(l[0]), int(l[1])), (int(l[2]), int(l[3])), (255, 255, 255), 2, 8, 0)
            # print(max_r0)
            # top_img = top_img.astype(np.uint8)
            # cv2.imshow("top_img", top_img)
            # cv2.waitKey(0)
            if max_r0 > max_r:
                max_r = max_r0
                max_line = l
        # bottom_img = bottom_img.astype(np.uint8)
        # cv2.line(bottom_img, (int(max_line[0]), int(max_line[1])), (int(max_line[2]), int(max_line[3])), (255, 255, 255), 2, 8, 0)
        # cv2.imshow("bottom_img", bottom_img)
        # cv2.waitKey(0)
        max_line[0] += leftCol
        max_line[2] += leftCol
        max_line[1] += leftRow
        max_line[3] += leftRow
        line_dict["B"] = max_line

        roi = cv2.bitwise_and(roi, roi, mask=hole)
        rect = self.cal_rect_point(line_dict)
        warped = self.warp_img(roi, rect)
        return warped

    def line_angle(self, line):
        return (line[3] - line[1]) / ((line[2] - line[0]) + 1e-6)

    def roi_get(self, img, **args):
        hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # 转换位HSV格式
        lower_param = np.array(args["roi_mask_Low"])
        upper_param = np.array(args["roi_mask_high"])
        mask = cv2.inRange(hsv_img, lower_param, upper_param)
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        max_cnts = [0]
        for cnt in cnts:
            if len(cnt) > len(max_cnts):
                max_cnts = cnt
        hole = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
        cv2.drawContours(hole, [max_cnts], -1, 255, -1)
        max_h = int(max(max_cnts[:, :, 1]))
        min_h = int(min(max_cnts[:, :, 1]))
        max_v = int(max(max_cnts[:, :, 0]))
        min_v = int(min(max_cnts[:, :, 0]))
        return max_h, min_h, max_v, min_v, hole

    def warp_img(self, img, rect):
        tl, tr, bl, br = rect
        widthA = np.sqrt(((tl[0] - tr[0]) ** 2) + ((tl[1] - tr[1]) ** 2))
        widthB = np.sqrt(((bl[0] - br[0]) ** 2) + ((bl[1] - br[1]) ** 2))
        widthMax = max(int(widthB), int(widthA))

        heightA = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
        heightB = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
        heightMax = max(int(heightA), int(heightB))
        pts1 = np.float32([tl, tr, bl, br])
        width = widthMax
        height = heightMax
        pts2 = np.float32([[0, 0], [width - 1, 0], [0, height - 1], [width - 1, height - 1]])
        M = cv2.getPerspectiveTransform(pts1, pts2)
        warped = cv2.warpPerspective(img, M, (width, height))
        return warped, 1

    def cal_rect_point(self, line_dict):
        def crossPointsOfLines(line1, line2):
            x1, y1, x2, y2 = line1
            x3, y3, x4, y4 = line2
            k1 = (y2 - y1) / ((x2 - x1) + 0.00001)
            k2 = (y4 - y3) / ((x4 - x3) + 0.00001)
            if k1 == k2:
                return None
            x = (k2 * x3 - k1 * x1 + y1 - y3) / (k2 - k1)
            y = k1 * (x - x1) + y1
            return (int(x), int(y))

        rect = []
        x, y = crossPointsOfLines(line_dict["L"], line_dict["T"])
        rect.append([x, y])
        x, y = crossPointsOfLines(line_dict["R"], line_dict["T"])
        rect.append([x, y])
        x, y = crossPointsOfLines(line_dict["L"], line_dict["B"])
        rect.append([x, y])
        x, y = crossPointsOfLines(line_dict["R"], line_dict["B"])
        rect.append([x, y])
        return rect
