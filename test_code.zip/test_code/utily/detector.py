from .PerspectiveTrans import PerspectiveTrans
from .rectD import rectD
from .recognition import recognition
from .cfg import load_cfg
import cv2


class detector:
    def __init__(self, config_path):
        args = load_cfg(config_path)
        self.PerspectiveTrans = PerspectiveTrans(args["PerspectiveTrans_path"])
        self.rectD = rectD(args["rectD_path"])
        self.recognition = recognition(args["recognition_path"])

    def __call__(self, img, die_lose_flag):
        try:
            img, have_wafer_flag = self.PerspectiveTrans(img)
            if have_wafer_flag == 0:
                return 0, 0, 0
            # cv2.imshow('imgimg',img)
            # cv2.waitKey(0)
            rect_axis = self.rectD(img)
            reuslt_mat, result_img = self.recognition(img, rect_axis, die_lose_flag)
            return reuslt_mat, result_img, 1
        except:
            return 0, 0, 0

