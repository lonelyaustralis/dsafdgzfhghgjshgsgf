import pandas as pd
import cv2
import numpy as np

# import time
from pyzbar.pyzbar import decode


class Bc128ADecode:
    # def __init__(self):
    #     # self.code128a = pd.read_csv(data_path)
    #     pass

    def __call__(self, img):
        # start_time = time.time()
        # 获取矫正后的图片
        warp_img = self.roi_get(img)
        # print("warp_img: {}".format(time.time() - start_time))
        code = decode(warp_img)
        return code

    def white_roi_get(self, img):
        img = img[2700:3000, 1200:2200]

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array([99, 54, 125]), np.array([127, 255, 255]))
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        # cv2.imshow("mask", mask)
        max_cnts = [0]
        for cnt in cnts:
            if len(cnt) > len(max_cnts):
                max_cnts = cnt
        # cv2.drawContours(img, [max_cnts], -1, (255, 0, 0))
        # cv2.imshow("img", img)
        # 获取点的全部X\Y坐标
        box = cv2.boundingRect(max_cnts)
        img = img[box[1] + 15 : box[1] + box[3] - 15, box[0] + 50 : box[0] + box[2] - 50]
        # box = cv2.boxPoints(box)
        # box = np.int0(box)
        # cv2.drawContours(img, [box], -1, (255, 0, 0))
        # cv2.imshow("img", img)

        # cv2.imshow("img_patch", img_patch)
        # cv2.waitKey(0)
        # 在晶圆上定位白色标签位置的预留接口，以及负责将图片进行等比例缩放
        h, w = img.shape[:2]
        resize_h = int(h / (w / 600))
        img = cv2.resize(img, (600, resize_h))
        # cv2.imwrite("dd.jpg", img)
        # cv2.imshow("img", img)
        # cv2.waitKey(0)
        return img

    def roi_get(self, img):
        """_summary_
        查找条形码所在区域，并将条形码图片进行矫正
        Parameters
        ----------
        img : _type_
            np.ndarray
            _description_
            从晶圆上截取的大致条形码所在区域的图片

        Returns
        -------
        _type_
            np.ndarray
            _description_
            矫正后的图片
        """
        # 在晶圆上定位白色标签位置的预留接口，以及负责将图片进行等比例缩放
        img = self.white_roi_get(img)
        # 在白色标签里面查找黑色
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (0, 0, 0), (255, 255, 160))
        # 膨胀mask
        mask = cv2.dilate(mask, None, iterations=2)
        # cv2.imshow("mask", mask)
        # cv2.waitKey(0)
        """
        查找条形码轮廓，首先从上到下，从左到右查找到条形码左边第一个条线的一个点，再从上到下，从右到左找到右边第一个条线的一个点
        使用一条直接将这两个点连接起来，再调用opencv查找轮廓的函数，这样可以将整块条形码视为一个轮廓，再找到这个轮廓的最小外接矩形，
        就可以找到需要矫正的4点坐标。
        """
        for i in range(0, mask.shape[1]):
            for j in range(0, mask.shape[0]):
                if mask[j][i] == 255:
                    min_left = [i, j]
                    break
        for i in range(mask.shape[1] - 1, 0, -1):
            for j in range(0, mask.shape[0]):
                if mask[j][i] == 255:
                    max_right = [i, j]
                    break
        # 在mask上将两个点连接起来
        mask = cv2.line(mask, min_left, max_right, (255, 255, 255), 2)
        # cv2.imshow("mask2", mask)
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        # 查找最长的轮廓作为目标轮廓
        max_cnts = [0]
        for cnt in cnts:
            if len(cnt) > len(max_cnts):
                max_cnts = cnt
        min_rect = cv2.minAreaRect(max_cnts)
        box = cv2.boxPoints(min_rect)
        box = np.int0(box)
        # cv2.imwrite('test2.jpg', img)
        # cv2.drawContours(img, [box], -1, (255, 0, 0))
        # cv2.imshow("img", img)
        # 将最小矩形的坐标排列调整为，左上，左下，右上，右下
        box = box[np.argsort(box, axis=0)[:, 0]]
        if box[0, 0] > box[1, 0]:
            box[0, 0], box[1, 0] = box[1, 0], box[0, 0]
        if box[2, 0] > box[3, 0]:
            box[2, 0], box[3, 0] = box[3, 0], box[2, 0]
        warp_img = self.warp_img(img, box)
        # cv2.imshow("warp_img", warp_img)
        # cv2.waitKey(0)
        return warp_img

    def warp_img(self, img, rect):

        tl, bl, tr, br = rect
        widthA = np.sqrt(((tl[0] - tr[0]) ** 2) + ((tl[1] - tr[1]) ** 2))
        widthB = np.sqrt(((bl[0] - br[0]) ** 2) + ((bl[1] - br[1]) ** 2))
        widthMax = max(int(widthB), int(widthA))

        heightA = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
        heightB = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
        heightMax = max(int(heightA), int(heightB))
        pts1 = np.float32([tl, tr, bl, br])
        width = widthMax
        height = heightMax
        pts2 = np.float32([[0, 0], [width - 1, 0], [0, height - 1], [width - 1, height - 1]])
        M = cv2.getPerspectiveTransform(pts1, pts2)
        warped = cv2.warpPerspective(img, M, (width, height))
        return warped

    # def binary_img_get(self, warp_img):
    #     """_summary_

    #     Parameters
    #     ----------
    #     warp_img : _type_
    #         np.ndarray
    #         _description_
    #         矫正后的图片
    #     Returns
    #     -------
    #     _type_
    #         np.ndarray 1-D
    #         _description_
    #         条形码序列
    #     """
    #     # 对图片使用双边滤波，使得图片中纹理边缘更加明显
    #     warp_img = cv2.bilateralFilter(warp_img, 5, 120, 70)
    #     # 图片强制拉伸为600*300
    #     warp_img = cv2.resize(warp_img, (1200, 600))

    #     warp_img = cv2.cvtColor(warp_img, cv2.COLOR_BGR2GRAY)
    #     # cv2.imwrite('test.jpg', warp_img)
    #     # cv2.imshow("warp_img", warp_img)
    #     # 二值化处理
    #     binary = cv2.threshold(warp_img, 110, 255, cv2.THRESH_BINARY)[1]
    #     # tt = np.zeros_like(binary)
    #     # cv2.imshow("binary", binary)
    #     # cv2.waitKey(0)
    #     # 转化为bool类型
    #     binary = binary == 255
    #     # 取图片中间段100行数据进行垂直方向的相加，将数值大于70的列视为白边，小于70的列视为黑边
    #     binary_sum = binary[100:200, :].sum(axis=0)
    #     binary_sum = binary_sum > 70
    #     tt[:, binary_sum] = 255
    #     # cv2.imshow("tt", tt)
    #     # cv2.waitKey(0)
    #     return binary_sum

    # def decode(self, binary_sum):
    #     """_summary_

    #         Parameters
    #         ----------
    #         binary_sum : _type_
    #             np.ndarray 1-D
    #             _description_
    #             条形码序列
    #         Returns
    #         -------
    #         _type_
    #         str or None
    #             _description_
    #             解码结果
    #     """

    #     def array2str(x):
    #         # 用于将1-D数组转化为数字
    #         start = ""
    #         for i in x:
    #             start = start + str(i)
    #         return int(start)

    #     # 条形码的开始与结束均为黑边，所以头尾的白边不参与解码，故而先找出头尾黑边的位置
    #     code = ""
    #     for i in range(len(binary_sum)):
    #         if binary_sum[i] == False:
    #             strat_index = i
    #             break
    #     for i in range(len(binary_sum) - 1, -1, -1):
    #         if binary_sum[i] == False:
    #             end_index = i
    #             break

    #     # LastTimeFlag代表上一时刻，边的属性，True代表白边，False代表黑边
    #     LastTimeFlag = False
    #     # 用于存储边的单位长度
    #     num_list = []
    #     # 用于存储边的当前像素长度
    #     count = 0
    #     for i in range(strat_index, end_index + 1):
    #         if binary_sum[i] == True:
    #             if LastTimeFlag == False:
    #                 # 根据统计，当将图片resize为600*300时，边的单位长度为4或者5个像素，所以取4.5作为边的一个单位
    #                 num = round(count / 9)
    #                 if num > 0:
    #                     num_list.append(num)
    #                 count = 1
    #                 LastTimeFlag = True
    #             else:
    #                 count += 1
    #         else:
    #             if LastTimeFlag == True:
    #                 num = round(count / 9)
    #                 if num > 0:
    #                     num_list.append(num)
    #                 count = 1
    #                 LastTimeFlag = False
    #             else:
    #                 count += 1
    #     num = round(count / 9)
    #     if num > 0:
    #         num_list.append(num)
    #     if (len(num_list) - 7) % 6 != 0:
    #         # 结束码长度为7，其他码的长度为6
    #         # 位数不正确，解码失败
    #         return None
    #     num_list = np.array(num_list)
    #     num_list_no_stop = num_list[0:-7].reshape(-1, 6)
    #     if array2str(num_list_no_stop[0]) != 211412:
    #         # 起始位不正确，解码失败
    #         return None
    #     val_code = 103
    #     # BandCode_V = list(map(array2str, num_list_no_stop[1 : num_list_no_stop.shape[0] - 1]))
    #     for i in range(1, num_list_no_stop.shape[0] - 1):
    #         # for BandCode in BandCode_V:
    #         BandCode = array2str(num_list_no_stop[i])
    #         print(BandCode)
    #         try:
    #             t_id = self.code128a[(self.code128a.BandCode == BandCode)].index.tolist()[0]
    #         except:
    #             # 解码失败
    #             return None
    #         val_code += t_id * i
    #         string = self.code128a.Code128A[t_id]
    #         code += string
    #     val_id = val_code % 103
    #     val_BandCode = array2str(num_list_no_stop[num_list_no_stop.shape[0] - 1])
    #     read_val_id = self.code128a[(self.code128a.BandCode == val_BandCode)].index.tolist()[0]
    #     if read_val_id != val_id:
    #         # 校验码不匹配，解码失败
    #         return None
    #     return code

