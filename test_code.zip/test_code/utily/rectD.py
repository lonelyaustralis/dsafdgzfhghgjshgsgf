from .cfg import load_cfg
from .utils import line_dect, img_filter
import cv2
import numpy as np


class rectD:
    def __init__(self, config_path):
        self.args = load_cfg(config_path)

    def __call__(self, img):

        img_blur = img.copy()
        img_blur[:, :, 0] = cv2.equalizeHist(img[:, :, 0])
        img_blur[:, :, 1] = cv2.equalizeHist(img[:, :, 1])
        img_blur[:, :, 2] = cv2.equalizeHist(img[:, :, 2])
        img = img_filter(img_blur, **self.args["Filter"])
        h = img.shape[0]
        w = img.shape[1]
        Canny_threshold = self.args["Canny_threshold"]
        # cv2.imshow("img", img)
        canny_img = cv2.Canny(img_blur, Canny_threshold[0], Canny_threshold[1])
        # cv2.imshow("canny", canny_img)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        # scale = self.args["h_scale"]
        scale = int(np.sqrt(w) * 2.8)
        threshold2 = self.args["threshold2"]
        # 识别横线
        dilatedcol = line_dect(canny_img, scale, "h")
        img_plane = np.zeros_like(dilatedcol)
        img_plane = np.bitwise_or(img_plane, dilatedcol)

        # cv2.imshow("dilatedcol", dilatedcol)
        self.h_line = self.line_nms(dilatedcol, "h", self.args["h_line_nums"], self.args["hnms_threshold1"], threshold2)
        # 识别竖线
        # scale = self.args["v_scale"]
        scale = int(np.sqrt(h) * 2.8)
        dilatedrow = line_dect(canny_img, scale, "v")
        img_plane = np.bitwise_or(img_plane, dilatedrow)
        img_plane = cv2.cvtColor(img_plane, cv2.COLOR_GRAY2BGR)
        img_plane = np.bitwise_or(img_plane, img)
        # cv2.imshow("img_plane", img_plane)
        self.v_line = self.line_nms(dilatedrow, "v", self.args["v_line_nums"], self.args["vnms_threshold1"], threshold2)
        self.rect_axis()
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        return self.rect_axis_list

    def line_nms(self, dilate, mode, line_nums, threshold1, threshold2):
        display_plane = np.zeros_like(dilate)
        row, col = dilate.shape
        if mode == "h":
            dilate_1d = dilate.sum(axis=1)
            base_line = row
            second_line_thr = 2
        elif mode == "v":
            dilate_1d = dilate.sum(axis=0)
            base_line = col
            second_line_thr = 2
        else:
            raise ValueError("mode must be 'h' or 'v'")
        dilate_1d_origin = dilate_1d.copy()
        arg_sort = np.argsort(dilate_1d)
        arg_sort = arg_sort[::-1]
        for i in range(len(arg_sort)):
            if dilate_1d[arg_sort[i]] == 0:
                continue
            for j in range(i + 1, len(arg_sort)):
                if np.abs(arg_sort[i] - arg_sort[j]) < (1 / threshold1) * base_line:
                    dilate_1d[arg_sort[j]] = 0

        arg_sort = np.argsort(dilate_1d)
        arg_sort = arg_sort[::-1]
        arg_sort = arg_sort[:line_nums]

        # if mode == "h":
        #     display_plane[arg_sort, :] = 255
        # if mode == "v":
        #     display_plane[:, arg_sort] = 255
        # cv2.imshow("display-1" + mode, display_plane)

        arg_sort = self.head_tail_cheak(base_line, arg_sort, 8)
        arg_sort = np.sort(arg_sort)
        arg_sort_origin = arg_sort.copy()

        # if mode == "h":
        #     display_plane[arg_sort, :] = 255
        # if mode == "v":
        #     display_plane[:, arg_sort] = 255
        # cv2.imshow("display0" + mode, display_plane)

        for i in range(1, len(arg_sort_origin) - 1):
            search_left = int(max(0, arg_sort_origin[i] - threshold2))
            search_right = int(min(base_line, arg_sort_origin[i] + threshold2))
            temp_arg_sort = np.argsort(dilate_1d_origin[search_left:search_right])
            for i in range(len(temp_arg_sort) - 2, -1, -1):
                if abs(temp_arg_sort[i] - temp_arg_sort[-1]) >= second_line_thr:
                    target_line = temp_arg_sort[i]
                    break
            arg_sort = np.insert(arg_sort, 0, target_line + search_left)

        arg_sort = np.sort(arg_sort)
        # if mode == "h":
        #     display_plane[arg_sort, :] = 255
        # if mode == "v":
        #     display_plane[:, arg_sort] = 255
        # cv2.imshow("display" + mode, display_plane)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        return arg_sort

    def head_tail_cheak(self, base_line, argsort, check_raido):
        head_check = False
        tail_check = False
        for i in range(len(argsort)):
            if 0 <= argsort[i] <= check_raido:
                head_check = True
                # print('head_check')
            if base_line - check_raido <= argsort[i] <= base_line:
                tail_check = True
                # print('tail_check')
            if head_check and tail_check:
                break
        if head_check is False:
            argsort = np.insert(argsort, 0, 2)
            argsort = np.delete(argsort, -1)
        if tail_check is False:
            argsort = np.insert(argsort, 0, base_line - 3)
            argsort = np.delete(argsort, -1)
        return argsort

    def rect_axis(self):
        self.rect_axis_list = []
        for i in range(0, len(self.h_line), 2):
            for j in range(0, len(self.v_line), 2):
                left_top = [self.v_line[j], self.h_line[i]]
                right_bottom = [self.v_line[j + 1], self.h_line[i + 1]]
                self.rect_axis_list.append([left_top, right_bottom])
