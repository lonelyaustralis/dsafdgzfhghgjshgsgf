from .cfg import load_cfg
from .utils import img_filter, mask_img
import cv2
import numpy as np


class recognition:
    def __init__(self, config_path):
        self.args = load_cfg(config_path)

    def __call__(self, img, rect_axis, die_lose_flag=True):
        if die_lose_flag is True:
            die_lose_list = []
            avg_backgroud_color = np.zeros(3)
            avg_backgroud_color_count = 0
        mask_mat = np.load(self.args["mask_mat_path"])
        mask_list = mask_mat.flatten()
        mask_mat_row, mask_mat_col = mask_mat.shape
        img_copy = img.copy()

        imgequ = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(3, 3))
        img_copy[:, :, 0] = imgequ.apply(img_copy[:, :, 0])
        img_copy[:, :, 1] = imgequ.apply(img_copy[:, :, 1])
        img_copy[:, :, 2] = imgequ.apply(img_copy[:, :, 2])
        img_copy = img_filter(img_copy, **self.args["Filter"])
        # cv2.imshow("img_copy", img_copy)
        canny_img = cv2.Canny(img_copy, self.args["Canny_threshold"][0], self.args["Canny_threshold"][1])
        # cv2.imshow("canny_img", canny_img)
        # Black_Point_Color_Mask = self.args["Black_Point_Color_Mask"]
        # Backward_Color_Mask = self.args["Backward_Color_Mask"]
        # cv2.imshow("canny", canny_img)
        for index, axis in enumerate(rect_axis):
            if mask_list[index] == 2:
                continue
            left_x, left_y = axis[0]
            right_x, right_y = axis[1]
            # roi_zoom = self.args["roi_zoom"]
            roi_zoom = {}
            # cv2.putText(img, str(int(right_y - left_y)), (left_x + 6, left_y + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
            if right_y - left_y <= 25:
                roi_zoom["left_y"] = 0
                roi_zoom["right_y"] = 0
            elif right_y - left_y <= 29:
                roi_zoom["left_y"] = 1
                roi_zoom["right_y"] = -1
            elif right_y - left_y <= 33:
                roi_zoom["left_y"] = 4
                roi_zoom["right_y"] = -3
            else:
                roi_zoom["left_y"] = 6
                roi_zoom["right_y"] = -6

            if right_x - left_x <= 54:
                roi_zoom["left_x"] = 2
                roi_zoom["right_x"] = -2
            # elif right_y - left_y <= 30:
            #     roi_zoom["left_y"] = 3
            #     roi_zoom["right_y"] = -3
            else:
                roi_zoom["left_x"] = 4
                roi_zoom["right_x"] = -4
            # roi_zoom["left_y"] = int(0.15 * (right_y - left_y))
            # roi_zoom["right_y"] = -int(0.2 * (right_y - left_y))
            # roi_zoom["left_x"] = int(0.1 * (right_x - left_x))
            # roi_zoom["right_x"] = -int(0.1 * (right_x - left_x))
            cut_img = canny_img[
                left_y + roi_zoom["left_y"] : right_y + roi_zoom["right_y"], left_x + roi_zoom["left_x"] : right_x + roi_zoom["right_x"]
            ]
            cut_img_color = img[
                left_y + roi_zoom["left_y"] : right_y + roi_zoom["right_y"], left_x + roi_zoom["left_x"] : right_x + roi_zoom["right_x"]
            ]
            cut_img = cv2.dilate(cut_img, np.ones((3, 3), np.uint8), iterations=self.args["dilate_iterations"])
            # if index == 71:
            #     print("8")
            #     cv2.imwrite("ff.jpg".format(index), cut_img)
            cnt = cv2.findContours(cut_img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]

            # boundingRect_list = []
            if die_lose_flag is True:
                if cnt:
                    back_mean_point = cut_img_color.sum(axis=(0, 1))
                    sub_point_num = cut_img.sum() / 255
                    # cut_img = cv2.cvtColor(cut_img, cv2.COLOR_GRAY2BGR)
                    roi_sum = cv2.bitwise_and(cut_img_color, cut_img_color, mask=cut_img).sum(axis=(0, 1))
                    # for k in cnt:
                    #     rect = cv2.boundingRect(k)
                    #     boundingRect_list.append(rect)
                    #     rect_img = cut_img_color[rect[1] : rect[1] + rect[3], rect[0] : rect[0] + rect[2]]
                    #     # f1 = rect_img.sum(axis=(0, 1))
                    #     back_mean_point -= rect_img.sum(axis=(0, 1))
                    #     sub_point_num += rect_img.shape[0] * rect_img.shape[1]
                    if cut_img_color.shape[0] * cut_img_color.shape[1] == sub_point_num:
                        sub_point_num -= 1
                    # back_mean_point = back_mean_point / (cut_img_color.shape[0] * cut_img_color.shape[1] - sub_point_num)
                    back_mean_point = (back_mean_point - roi_sum) / (cut_img_color.shape[0] * cut_img_color.shape[1] - sub_point_num)
                    avg_backgroud_color += back_mean_point
                    avg_backgroud_color_count += 1
            if cnt:
                flag = 0
                for i in range(len(cnt)):
                    rect = cv2.boundingRect(cnt[i])
                    rate = rect[2] / rect[3]
                    area = rect[2] * rect[3]
                    # if index == 64:
                    #     print("8")
                    if rate > 1:
                        rate = 1 / rate
                    if (rate >= (self.args["L_W_ratio_threshold"] + 0.1) and area > 10 and area < 150) or (
                        (rate >= self.args["L_W_ratio_threshold"] and area >= 150 and area < 500)
                    ):
                        # cv2.putText(img, str(int(area)), (left_x + 6, left_y + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
                        if rect[3] > 3:
                            rect_left_change = 2
                            rect_right_change = -1
                        elif rect[3] > 2:
                            rect_left_change = 1
                            rect_right_change = -1
                        else:
                            rect_left_change = 0
                            rect_right_change = 0
                        if rect[2] > 2:
                            rect_top_change = 1
                            rect_bottom_change = -1
                        else:
                            rect_top_change = 0
                            rect_bottom_change = 0
                        rect_img2 = cut_img_color[
                            rect[1] + rect_left_change : rect[1] + rect[3] + rect_right_change, rect[0] + rect_top_change : rect[0] + rect[2] + rect_bottom_change
                        ]
                        rect_mean_point = rect_img2.mean(axis=(0, 1))
                        # back_mean_point = (cut_img_color.sum(axis=(0, 1)) - rect_img2.sum(axis=(0, 1))) / (
                        #     cut_img_color.shape[0] * cut_img_color.shape[1] - rect_img2.shape[0] * rect_img2.shape[1]
                        # )
                        distcance = np.linalg.norm(rect_mean_point - back_mean_point, 2)
                        if distcance > 25:
                            flag = 1
                            color = (0, 0, 255)
                            mask_list[index] = 0
                            cv2.rectangle(
                                img,
                                (left_x + roi_zoom["left_x"], left_y + roi_zoom["left_y"]),
                                (right_x + roi_zoom["right_x"], right_y + roi_zoom["right_y"]),
                                color,
                                1,
                            )
                            break
                if flag == 0:
                    if die_lose_flag is False:
                        color = (0, 255, 0)
                        mask_list[index] = 1
                        cv2.rectangle(
                            img,
                            (left_x + roi_zoom["left_x"], left_y + roi_zoom["left_y"]),
                            (right_x + roi_zoom["right_x"], right_y + roi_zoom["right_y"]),
                            color,
                            1,
                        )
                    else:
                        die_lose_dict = {}
                        die_lose_dict["left_x"] = left_x + roi_zoom["left_x"]
                        die_lose_dict["left_y"] = left_y + roi_zoom["left_y"]
                        die_lose_dict["right_x"] = right_x + roi_zoom["right_x"]
                        die_lose_dict["right_y"] = right_y + roi_zoom["right_y"]
                        die_lose_dict["index"] = index
                        die_lose_list.append(die_lose_dict)
                    # cv2.imwrite("ture/No_{}_index_{}.jpg".format(i, index), cut_img_color)

            else:
                if die_lose_flag is False:
                    mask_list[index] = 1
                    color = (0, 255, 0)
                    # mask_back = mask_img(cut_img_color, **Backward_Color_Mask)
                    # if ((mask_back // 255).sum() / (mask_back.shape[0] * mask_back.shape[1])) > 0.5:
                    #     # if np.any(mask_back == 255):
                    #     color = (0, 255, 0)
                    #     mask_list[index] = 1
                    # else:
                    #     mask_list[index] = 0
                    #     # cv2.imwrite("true/No_{}_index_{}.jpg".format(i, index), cut_img_color)
                    #     color = (0, 255, 255)
                    cv2.rectangle(
                        img,
                        (left_x + roi_zoom["left_x"], left_y + roi_zoom["left_y"]),
                        (right_x + roi_zoom["right_x"], right_y + roi_zoom["right_y"]),
                        color,
                        1,
                    )
                else:
                    die_lose_dict = {}
                    die_lose_dict["left_x"] = left_x + roi_zoom["left_x"]
                    die_lose_dict["left_y"] = left_y + roi_zoom["left_y"]
                    die_lose_dict["right_x"] = right_x + roi_zoom["right_x"]
                    die_lose_dict["right_y"] = right_y + roi_zoom["right_y"]
                    die_lose_dict["index"] = index
                    die_lose_list.append(die_lose_dict)
            cv2.putText(img, "{}".format(index), (left_x + 4, left_y + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
        if die_lose_flag:
            avg_backgroud_color /= avg_backgroud_color_count
            for die_lose_dict in die_lose_list:
                # if die_lose_dict["index"] == 212:
                #     print("dd")
                rect_img = img[die_lose_dict["left_y"] : die_lose_dict["right_y"], die_lose_dict["left_x"] : die_lose_dict["right_x"]]
                rect_mean_point = rect_img.mean(axis=(0, 1))
                distcance_back = np.linalg.norm(rect_mean_point - avg_backgroud_color)
                # cv2.putText(
                #     img,
                #     str(int(distcance)),
                #     (die_lose_dict["left_x"] + 6, die_lose_dict["left_y"] + 15),
                #     cv2.FONT_HERSHEY_SIMPLEX,
                #     0.3,
                #     (254, 33, 195),
                #     1,
                # )
                if distcance_back > 40:
                    mask_list[die_lose_dict["index"]] = 0
                    color = (0, 255, 255)
                else:
                    mask_list[die_lose_dict["index"]] = 1
                    color = (0, 255, 0)
                cv2.rectangle(
                    img, (die_lose_dict["left_x"], die_lose_dict["left_y"]), (die_lose_dict["right_x"], die_lose_dict["right_y"]), color, 1,
                )

            # cv2.putText(img, "{}".format(int(right_x - left_x)), (left_x + 6, left_y + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
            # if color == (0, 0, 255):
            # cv2.putText(img, str(rect[2] * rect[3]), (left_x + 6, left_y + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
            # cv2.putText(img, str(int(distcance)), (left_x + 6, left_y + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (254, 33, 195), 1)
        result_mat = mask_list.reshape(mask_mat_row, mask_mat_col)
        img = cv2.resize(img, (self.args["output_img_size"]))
        return result_mat, img
