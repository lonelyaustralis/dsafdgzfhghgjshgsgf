from yacs.config import CfgNode


# cfg = CfgNode(new_allowed=True)
# cfg.save_dir = "./"
# cfg.FirstStage = CfgNode(new_allowed=True)
# cfg.FirstStage.Filter = CfgNode(new_allowed=True)
# cfg.SecondStage = CfgNode(new_allowed=True)


def load_cfg(cfg_file):
    cfg = CfgNode(new_allowed=True)
    cfg.merge_from_file(cfg_file)
    return cfg


if __name__ == "__main__":
    cfg = load_cfg("utily/WarpImage_v1.yaml")
    print(cfg)
